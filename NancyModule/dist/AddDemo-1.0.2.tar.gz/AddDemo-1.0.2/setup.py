from distutils.core import setup

setup(

    name ='AddDemo',
    version = "1.0.2",
    py_modules = ['AddDemo','nester'],
    author = 'Nancy',
    url = "www.nancyhome.com",
    description = "This is used for add two number",
    )
