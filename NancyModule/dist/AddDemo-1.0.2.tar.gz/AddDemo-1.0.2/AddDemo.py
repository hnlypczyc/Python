def Add(x, y):
    print (x+y)
